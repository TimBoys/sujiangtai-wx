
export default{
    zh:require("./zh"),
    en:require("./en")
}

